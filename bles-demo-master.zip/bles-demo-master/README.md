# Install

use "npm install" to install dependencies

# Run

use "npm run dev" to start the project locally after running "npm install"
view at - http://localhost:8000
