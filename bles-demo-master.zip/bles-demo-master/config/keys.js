//ignore these in .gitignore
module.exports = {
  google: {
    clientID:
      '710025853400-o8ecfgh1uke9jka3nrdc261869rggce4.apps.googleusercontent.com',
    clientSecret: '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',
  },
  mongodb: {
    dbURI:
      'mongodb+srv://blessuperuser:SJUSSkDDcfC68VX7@blestest.ghao5ix.mongodb.net/',
  },
  session: {
    cookieKey: 'thisissomesuperSECUREkeyFUn',
  },
  stripe: {
    clientID: 'ca_OYdMHkk2EBfYfHoWgbhCLLtrA77vg16W',
    clientSecret:
      'sk_test_51NZrNbCUAnsEcjI8RIRhyfPeFXFMbTAgmRnWLHuQ2mfV3m27xawvtcDmCMktVbxjKTkChwrYvGRAEd7oMxDyc2UP00OLXlL16b',
  },
};
